part of 'chips_bloc.dart';

@freezed
class ChipsEvent with _$ChipsEvent {
  const factory ChipsEvent.loaded() = _Loaded;
}
