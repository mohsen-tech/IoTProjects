# IOT Project

## Environment Variables

- `BASE_URL`  
  The base url of the API. e.g. <https://example.com>

## How to Build

```bash
flutter build apk --release --target-platform android-arm64,android-arm --dart-define=BASE_URL=https://iotproject.iran.liara.run
```
